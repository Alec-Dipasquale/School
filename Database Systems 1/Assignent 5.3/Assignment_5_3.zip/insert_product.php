<html>
<head>
  <title>Nicole's Graphic Designs Product Entry Results</title>
</head>
<body>
<h1>Nicole's Graphic Designs Product Entry Results</h1>
<?php
  // create short variable names
  $product_name=$_POST['product_name'];
  $product_description=$_POST['product_description'];
  $quantity=$_POST['quantity'];

  if (!$product_name || !$product_description || !$quantity) {
     echo "You have not entered all the required details.<br />"
          ."Please go back and try again.";
     exit;
  }

  if (!get_magic_quotes_gpc()) {
    $product_name = addslashes($product_name);
    $product_description = addslashes($product_description);
    $quantity = addslashes($quantity);
  }

  @ $db = new mysqli("localhost","dipasqa1_admin2","{.CfJMa&]fgl","dipasqa1_books");
  

  if (mysqli_connect_errno()) {
     echo "Error: Could not connect to database.  Please try again later.";
     exit;
  }

  $query = "insert into products values
            (NULL, '".$product_name."', '".$product_description."', '".$quantity."')";
  $result = $db->query($query);

  if ($result) {
      echo  $db->affected_rows." product inserted into database.";
  } else {
  	  echo "An error has occurred.  The item was not added.";
  }

  $db->close();
?>
</body>
</html>
